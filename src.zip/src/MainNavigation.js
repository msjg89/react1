import { Link } from "react-router-dom";

function MainNavidation(){
    return(

        <div>
            <nav>
                <ul>
                    <li>
                        <Link to='/'>All Blogs</Link>
                    </li>
                    <li>
                        <link to='/new-blog'>New blog</link>
                    </li>
                </ul>
            </nav>
        </div>

    )
}

export default MainNavidation;