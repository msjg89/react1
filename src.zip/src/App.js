
import MainNavidation from "./MainNavigation";
import { Routes, Route } from "react-router-dom";
import NewBlog from "./NewBlog";
import QAPics from "./QAPics";
import NotFound from "./NotFound";
import Blogs2 from "./Blogs2";

function App() {
 
  return (
    <div>
          <MainNavidation />
          <Routes>
              <Route path='/' element={<Blogs2 />} />
              <Route path="/new-blog" element={<NewBlog />} />
              <Route path="/new" element={<NewBlog />} />
              <Route path="/qa/pics/ :id" element={<QAPics />} />
              <Route path="*" element={<NotFound />} />
          </Routes>
    </div>
  );
  
}

export default App;
