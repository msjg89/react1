import { useState } from "react";
import { useNavigate } from "react-router-dom";

function NewBlog() {
    const [name, setName] = useState("");
    const [title, setTitle] = useState("");
    const [age, setAge] = useState(0);
    const [message, setMessage] = useState("");
    const history = useNavigate();

    function submitHandler(event) {

        event.preventDefault();

        const data = JSON.stringify({ "title": title, "author": name, "body": message});
        fetch('http://localhost:4000/blogs', {
            method: 'POST',
            body: data,
            headers: { 'Content-Type': 'application/json' }
        }).then(() => {
            history('/')
        });
    }

    return (
            <form onSubmit={submitHandler}>

                Name: <input type="text" onChange={(e) => setName(e.target.value)} />

                Title: <input type="text" onChange={(e) => setTitle(e.target.value)} />

                Message: <input type="text" onChange={(e) => setMessage(e.target.value)} />

                <button>Add blog</button>
            </form>
    )
}

export default NewBlog;